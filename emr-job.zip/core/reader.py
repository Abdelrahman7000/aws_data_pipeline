from pyspark.sql.functions import explode
#from core.cleaner import clean_column_names
import re


def clean_column_names(df):
    def normalize(c):
        c = c.lower()
        c = re.sub(r'[^a-z0-9]+', '_', c)
        return c.strip('_')

    return df.toDF(*[normalize(c) for c in df.columns])



def read_json_data(spark, path, entity_name):
    df = spark.read.option("multiLine", "true").json(path)
    
    df = df.select(explode("data").alias(entity_name))
    df = df.select(f"{entity_name}.*")
    
    df = clean_column_names(df)
    
    return df